﻿using System;
using System.Windows.Forms;
using SignIn_and_SignUp_Application_with_Windows_Foam.BL;

namespace SignIn_and_SignUp_Application_with_Windows_Foam.UI
{
    public partial class UserForm : Form
    {
        private MUser currentUser;

        public UserForm(MUser user)
        {
            InitializeComponent();
            this.currentUser = user;
        }

        private void UserForm_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "Welcome User: " + currentUser.getUserName();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
