﻿using SignIn_and_SignUp_Application_with_Windows_Foam.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SignIn_and_SignUp_Application_with_Windows_Foam.UI
{
    public class MUSERUI
    {
        public static int Menu()
        {
            int option;
            Console.WriteLine("1. SignIn");
            Console.WriteLine("2. SignUp");
            Console.Write("Enter Option = ");
            option = int.Parse(Console.ReadLine());
            return option;
        }

        public static MUser TakeInputWithoutRole()
        {
            Console.Write("Enter Name = ");
            string name = Console.ReadLine();
            Console.Write("Enter Password = ");
            string password = Console.ReadLine();

            if (name != null && password != null)
            {
                return new MUser(name, password);
            }
            return null;
        }

        public static MUser TakeInputWithRole()
        {
            Console.Write("Enter Name = ");
            string name = Console.ReadLine();
            Console.Write("Enter Password = ");
            string password = Console.ReadLine();
            Console.Write("Enter Role = ");
            string role = Console.ReadLine();

            if (name != null && password != null && role != null)
            {
                return new MUser(name, password, role);
            }
            return null;
        }

        public static void ShowMessage(string message)
        {
            Console.WriteLine(message);
        }
    }
}
