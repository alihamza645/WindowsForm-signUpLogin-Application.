﻿using System;
using System.Windows.Forms;
using SignIn_and_SignUp_Application_with_Windows_Foam.BL;

namespace SignIn_and_SignUp_Application_with_Windows_Foam.UI
{
    public partial class AdminForm : Form
    {
        private MUser currentUser;

        public AdminForm(MUser user)
        {
            InitializeComponent();
            this.currentUser = user;
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "Welcome Admin: " + currentUser.getUserName();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
