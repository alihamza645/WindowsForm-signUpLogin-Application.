﻿using System;
using System.Windows.Forms;
using SignIn_and_SignUp_Application_with_Windows_Foam.BL;

namespace SignIn_and_SignUp_Application_with_Windows_Foam.UI
{
    public partial class Loginform : Form
    {
        public Loginform()
        {
            InitializeComponent();
        }

        private void Loginform_Load(object sender, EventArgs e)
        {
            MUserBL.LoadUsersFromDatabase();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password!", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MUser user = new MUser(username, password);
            MUser loggedInUser = MUserBL.SignIn(user);

            if (loggedInUser == null)
            {
                MessageBox.Show("Invalid username or password!", "Login Failed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (loggedInUser.isAdmin())
            {
                MessageBox.Show("Welcome Admin: " + loggedInUser.getUserName(), "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                AdminForm adminForm = new AdminForm(loggedInUser);
                this.Hide();
                adminForm.ShowDialog();
                this.Show();
                ClearFields();
            }
            else
            {
                MessageBox.Show("Welcome User: " + loggedInUser.getUserName(), "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                UserForm userForm = new UserForm(loggedInUser);
                this.Hide();
                userForm.ShowDialog();
                this.Show();
                ClearFields();
            }
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            SignUpForm signUpForm = new SignUpForm();
            this.Hide();
            signUpForm.ShowDialog();
            this.Show();
        }

        private void ClearFields()
        {
            txtUsername.Clear();
            txtPassword.Clear();
            txtUsername.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
