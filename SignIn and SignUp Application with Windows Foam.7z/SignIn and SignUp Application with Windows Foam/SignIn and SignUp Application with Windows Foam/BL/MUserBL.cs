﻿using SignIn_and_SignUp_Application_with_Windows_Foam.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SignIn_and_SignUp_Application_with_Windows_Foam.BL
{
    public class MUser
    {
        public string name;
        public string password;
        public string role;

        public MUser(string name, string password)
        {
            this.name = name;
            this.password = password;
        }

        public MUser(string name, string password, string role)
        {
            this.name = name;
            this.password = password;
            this.role = role;
        }

        public string getUserName()
        {
            return name;
        }

        public string getUserPassword()
        {
            return password;
        }

        public string getUserRole()
        {
            return role;
        }

        public bool isAdmin()
        {
            return role == "Admin" || role == "admin" || role == "ADMIN";
        }
    }

    public class MUserBL
    {
        public static List<MUser> users = new List<MUser>();

        public static void LoadUsersFromDatabase()
        {
            users = MUserDL.ReadDataFromDatabase();
        }

        public static MUser SignIn(MUser user)
        {
            foreach (MUser storedUser in users)
            {
                if (user.getUserName() == storedUser.getUserName() &&
                    user.getUserPassword() == storedUser.getUserPassword())
                    return storedUser;
            }
            return null;
        }

        public static bool SignUp(MUser user)
        {
            bool inserted = MUserDL.AddUserToDatabase(user);

            if (inserted)
            {
                users.Add(user);
            }

            return inserted;
        }

        public static void AddUserToList(MUser user)
        {
            users.Add(user);
        }
    }
}