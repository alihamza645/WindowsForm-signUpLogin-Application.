﻿using SignIn_and_SignUp_Application_with_Windows_Foam.BL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SignIn_and_SignUp_Application_with_Windows_Foam.DL
{
    public class MUserDL
    {
        static string connStr = "Server=LENOVOTHINKBOOK;Database=BusinessApp;Trusted_Connection=True;";

        public static List<MUser> ReadDataFromDatabase()
        {
            List<MUser> users = new List<MUser>();

            using (SqlConnection conn = new SqlConnection(connStr))
            using (SqlCommand cmd = new SqlCommand(
                "SELECT Username, Password, Role FROM dbo.Users", conn))
            {
                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string name = reader.GetString(0);
                        string pass = reader.GetString(1);
                        string role = reader.GetString(2);

                        users.Add(new MUser(name, pass, role));
                    }
                }
            }

            return users;
        }

        public static bool AddUserToDatabase(MUser user)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            using (SqlCommand cmd = new SqlCommand(
                 "INSERT INTO dbo.Users (Username, Password, Role, CreatedAt) VALUES (@u, @p, @r, @c)", conn))
            {
                cmd.Parameters.Add("@u", SqlDbType.NVarChar, 100).Value = user.getUserName();
                cmd.Parameters.Add("@p", SqlDbType.NVarChar, 256).Value = user.getUserPassword();
                cmd.Parameters.Add("@r", SqlDbType.NVarChar, 50).Value = user.getUserRole();
                cmd.Parameters.Add("@c", SqlDbType.DateTime).Value = DateTime.Now;

                conn.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 2627 || ex.Number == 2601)
                        return false;
                    else
                        throw;
                }
            }
        }
    }
}
